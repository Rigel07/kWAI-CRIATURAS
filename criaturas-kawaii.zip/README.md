# Criaturas Kawaii (Forge 1.20.1)

Seis criaturas que aparecen solas por el mundo. Compañero opcional de **Aventuras Kawaii**.

| Criatura | Donde | Que hace |
|---|---|---|
| Nubecito | Prados, llanuras | Se esquila (tijeras) para sacar Algodon de Nube y le vuelve a crecer |
| Cangrejito | Playas | Se esconde en su concha si te acercas de pie. Agachate y te regala conchas |
| Pinguinito | Biomas nevados | Se doma con pescado. Te sigue, te quita el frio y te da Gracia del Delfin |
| Mariposita | Prados y bosques | Planta florecillas sobre la hierba. 5 colores |
| Ardillita | Bosques y taigas | Recoge brotes de arbol del suelo y los planta |
| Erizito | Bosques y taigas | Se hace bolita al ser atacado y pincha al agresor |

Con **Aventuras Kawaii** instalado, el Azucar Cristalizado y el Jarabe de Gominola son golosinas
para todas ellas (curan y activan un efecto propio), y se desbloquean 3 recetas extra.

Compilar: `gradle build` (Java 17, Gradle 8.1.1). El .jar queda en `build/libs/`.

package com.criaturaskawaii.registry;

import com.criaturaskawaii.CriaturasKawaii;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CriaturasKawaii.MODID);

    public static final RegistryObject<Item> ALGODON_NUBE = ITEMS.register("algodon_nube",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> CONCHA = ITEMS.register("concha_kawaii",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PLUMA_POLAR = ITEMS.register("pluma_polar",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> POLEN = ITEMS.register("polen_arcoiris",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PUA_SUAVE = ITEMS.register("pua_suave",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BELLOTA = ITEMS.register("bellota_dulce",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.3F).fast().build())));

    public static final RegistryObject<Item> NUBECITO_EGG = ITEMS.register("nubecito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.NUBECITO, 0xFFFFFF, 0xFFB8D0, new Item.Properties()));
    public static final RegistryObject<Item> CANGREJITO_EGG = ITEMS.register("cangrejito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.CANGREJITO, 0xFF8A5B, 0xF7C6D9, new Item.Properties()));
    public static final RegistryObject<Item> PINGUINITO_EGG = ITEMS.register("pinguinito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.PINGUINITO, 0x2F3A5A, 0xFFB02E, new Item.Properties()));
    public static final RegistryObject<Item> MARIPOSITA_EGG = ITEMS.register("mariposita_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MARIPOSITA, 0xFF9EC8, 0x7FD6FF, new Item.Properties()));
    public static final RegistryObject<Item> ARDILLITA_EGG = ITEMS.register("ardillita_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ARDILLITA, 0xD9824B, 0xFFF0D6, new Item.Properties()));
    public static final RegistryObject<Item> ERIZITO_EGG = ITEMS.register("erizito_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ERIZITO, 0x6B4B3A, 0xF6D9B8, new Item.Properties()));
}

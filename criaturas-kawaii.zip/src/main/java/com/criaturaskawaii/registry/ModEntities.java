package com.criaturaskawaii.registry;

import com.criaturaskawaii.CriaturasKawaii;
import com.criaturaskawaii.entity.ArdillitaEntity;
import com.criaturaskawaii.entity.CangrejitoEntity;
import com.criaturaskawaii.entity.ErizitoEntity;
import com.criaturaskawaii.entity.MariposaEntity;
import com.criaturaskawaii.entity.NubecitoEntity;
import com.criaturaskawaii.entity.PinguinitoEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CriaturasKawaii.MODID);

    public static final RegistryObject<EntityType<NubecitoEntity>> NUBECITO = ENTITIES.register("nubecito",
            () -> EntityType.Builder.of(NubecitoEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.8F).clientTrackingRange(10).build("nubecito"));

    public static final RegistryObject<EntityType<CangrejitoEntity>> CANGREJITO = ENTITIES.register("cangrejito",
            () -> EntityType.Builder.of(CangrejitoEntity::new, MobCategory.CREATURE)
                    .sized(0.7F, 0.5F).clientTrackingRange(8).build("cangrejito"));

    public static final RegistryObject<EntityType<PinguinitoEntity>> PINGUINITO = ENTITIES.register("pinguinito",
            () -> EntityType.Builder.of(PinguinitoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.1F).clientTrackingRange(10).build("pinguinito"));

    public static final RegistryObject<EntityType<MariposaEntity>> MARIPOSITA = ENTITIES.register("mariposita",
            () -> EntityType.Builder.of(MariposaEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.4F).clientTrackingRange(8).build("mariposita"));

    public static final RegistryObject<EntityType<ArdillitaEntity>> ARDILLITA = ENTITIES.register("ardillita",
            () -> EntityType.Builder.of(ArdillitaEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.7F).clientTrackingRange(10).build("ardillita"));

    public static final RegistryObject<EntityType<ErizitoEntity>> ERIZITO = ENTITIES.register("erizito",
            () -> EntityType.Builder.of(ErizitoEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.55F).clientTrackingRange(10).build("erizito"));
}

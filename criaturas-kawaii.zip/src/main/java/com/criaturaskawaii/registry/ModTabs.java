package com.criaturaskawaii.registry;

import com.criaturaskawaii.CriaturasKawaii;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CriaturasKawaii.MODID);

    public static final RegistryObject<CreativeModeTab> CRIATURAS = TABS.register("criaturas",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.criaturaskawaii"))
                    .icon(() -> new ItemStack(ModItems.ALGODON_NUBE.get()))
                    .displayItems((params, output) -> {
                        ModItems.ITEMS.getEntries().forEach(item -> output.accept(item.get()));
                    })
                    .build());
}

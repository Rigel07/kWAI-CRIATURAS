package com.criaturaskawaii.event;

import com.criaturaskawaii.CriaturasKawaii;
import com.criaturaskawaii.entity.ArdillitaEntity;
import com.criaturaskawaii.entity.CangrejitoEntity;
import com.criaturaskawaii.entity.ErizitoEntity;
import com.criaturaskawaii.entity.MariposaEntity;
import com.criaturaskawaii.entity.NubecitoEntity;
import com.criaturaskawaii.entity.PinguinitoEntity;
import com.criaturaskawaii.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CriaturasKawaii.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.NUBECITO.get(), NubecitoEntity.createAttributes().build());
        event.put(ModEntities.CANGREJITO.get(), CangrejitoEntity.createAttributes().build());
        event.put(ModEntities.PINGUINITO.get(), PinguinitoEntity.createAttributes().build());
        event.put(ModEntities.MARIPOSITA.get(), MariposaEntity.createAttributes().build());
        event.put(ModEntities.ARDILLITA.get(), ArdillitaEntity.createAttributes().build());
        event.put(ModEntities.ERIZITO.get(), ErizitoEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void onSpawnPlacements(SpawnPlacementRegisterEvent event) {
        SpawnPlacements.Type ground = SpawnPlacements.Type.ON_GROUND;
        Heightmap.Types map = Heightmap.Types.MOTION_BLOCKING_NO_LEAVES;
        SpawnPlacementRegisterEvent.Operation or = SpawnPlacementRegisterEvent.Operation.OR;
        event.register(ModEntities.NUBECITO.get(), ground, map, ModEvents::dayMob, or);
        event.register(ModEntities.CANGREJITO.get(), ground, map, ModEvents::beachMob, or);
        event.register(ModEntities.PINGUINITO.get(), ground, map, ModEvents::dayMob, or);
        event.register(ModEntities.MARIPOSITA.get(), ground, map, ModEvents::dayMob, or);
        event.register(ModEntities.ARDILLITA.get(), ground, map, ModEvents::dayMob, or);
        event.register(ModEntities.ERIZITO.get(), ground, map, ModEvents::dayMob, or);
    }

    private static <T extends Mob> boolean dayMob(EntityType<T> type, ServerLevelAccessor level,
                                                  MobSpawnType reason, BlockPos pos, RandomSource random) {
        return level.getRawBrightness(pos, 0) > 8 && Mob.checkMobSpawnRules(type, level, reason, pos, random);
    }

    private static <T extends Mob> boolean beachMob(EntityType<T> type, ServerLevelAccessor level,
                                                    MobSpawnType reason, BlockPos pos, RandomSource random) {
        return level.getRawBrightness(pos, 0) > 8 && level.getBlockState(pos.below()).is(BlockTags.SAND);
    }
}

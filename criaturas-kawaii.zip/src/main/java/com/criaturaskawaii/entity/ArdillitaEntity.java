package com.criaturaskawaii.entity;

import com.criaturaskawaii.registry.ModItems;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Ardillita: reforesta el bosque. Recoge los brotes de arbol que encuentre
 * tirados (o que le des en la mano) y los planta por los alrededores.
 */
public class ArdillitaEntity extends KawaiiBase {

    public ArdillitaEntity(EntityType<? extends ArdillitaEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    private static boolean isSapling(ItemStack stack) {
        return Block.byItem(stack.getItem()) instanceof SaplingBlock;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new PlantSaplingGoal());
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    /** Planta un brote del tipo indicado en un hueco valido cercano. */
    private boolean plantNear(ItemStack sapling) {
        Block block = Block.byItem(sapling.getItem());
        if (!(block instanceof SaplingBlock)) {
            return false;
        }
        BlockState plant = block.defaultBlockState();
        for (int i = 0; i < 16; i++) {
            BlockPos pos = this.blockPosition().offset(this.random.nextInt(7) - 3, this.random.nextInt(3) - 1,
                    this.random.nextInt(7) - 3);
            if (this.level().getBlockState(pos).isAir() && plant.canSurvive(this.level(), pos)) {
                this.level().setBlock(pos, plant, 3);
                ((ServerLevel) this.level()).sendParticles(ParticleTypes.HAPPY_VILLAGER,
                        pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, 6, 0.3D, 0.3D, 0.3D, 0.0D);
                this.playSound(SoundEvents.GRASS_PLACE, 1.0F, 1.2F);
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onTreat(Player player) {
        this.spawnAtLocation(ModItems.BELLOTA.get());
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (isSapling(held)) {
            if (!this.level().isClientSide && this.plantNear(held)) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                this.showHearts();
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RABBIT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RABBIT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RABBIT_DEATH;
    }

    private class PlantSaplingGoal extends Goal {
        private ItemEntity target;
        private int delay;

        PlantSaplingGoal() {
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (--this.delay > 0) {
                return false;
            }
            this.delay = 20;
            List<ItemEntity> items = level().getEntitiesOfClass(ItemEntity.class,
                    getBoundingBox().inflate(8.0D, 3.0D, 8.0D), e -> e.isAlive() && isSapling(e.getItem()));
            if (items.isEmpty()) {
                return false;
            }
            this.target = items.get(0);
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive();
        }

        @Override
        public void start() {
            getNavigation().moveTo(this.target, 1.1D);
        }

        @Override
        public void tick() {
            if (distanceToSqr(this.target) < 2.5D) {
                ItemStack stack = this.target.getItem();
                if (plantNear(stack)) {
                    stack.shrink(1);
                    if (stack.isEmpty()) {
                        this.target.discard();
                    }
                }
                this.delay = 100;
                this.target = null;
            } else if (getNavigation().isDone()) {
                getNavigation().moveTo(this.target, 1.1D);
            }
        }
    }
}

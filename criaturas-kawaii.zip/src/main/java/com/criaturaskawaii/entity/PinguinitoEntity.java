package com.criaturaskawaii.entity;

import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/**
 * Pinguinito: se domestica con pescado (o con una golosina de Aventuras
 * Kawaii, que siempre funciona). Una vez tuyo te sigue con su bufanda rosa,
 * te quita el frio (nada de congelarte) y te da Gracia del Delfin al nadar.
 */
public class PinguinitoEntity extends KawaiiBase {
    private static final EntityDataAccessor<Boolean> TAMED =
            SynchedEntityData.defineId(PinguinitoEntity.class, EntityDataSerializers.BOOLEAN);
    private UUID owner;

    public PinguinitoEntity(EntityType<? extends PinguinitoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 14.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(TAMED, false);
    }

    public boolean isTamed() {
        return this.entityData.get(TAMED);
    }

    private void tameTo(Player player) {
        this.owner = player.getUUID();
        this.entityData.set(TAMED, true);
        this.showHearts();
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return !this.isTamed();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.owner != null) {
            tag.putUUID("Owner", this.owner);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            this.owner = tag.getUUID("Owner");
            this.entityData.set(TAMED, true);
        }
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.3D) {
            @Override
            public boolean canUse() {
                return !isTamed() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new FollowOwner());
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide || this.owner == null || this.tickCount % 20 != 0) {
            return;
        }
        Player player = this.level().getPlayerByUUID(this.owner);
        if (player != null && this.distanceToSqr(player) < 256.0D) {
            if (player.getTicksFrozen() > 0) {
                player.setTicksFrozen(0);
            }
            if (player.isInWater()) {
                player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 100, 0, true, false));
            }
        }
    }

    @Override
    protected void onTreat(Player player) {
        if (this.owner == null) {
            this.tameTo(player);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.COD) || held.is(Items.SALMON)) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                this.heal(4.0F);
                if (this.owner == null && this.random.nextInt(3) == 0) {
                    this.tameTo(player);
                } else {
                    this.showHearts();
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.CHICKEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.CHICKEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.CHICKEN_DEATH;
    }

    private class FollowOwner extends Goal {
        private Player target;
        private int recalc;

        FollowOwner() {
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (owner == null) {
                return false;
            }
            Player player = level().getPlayerByUUID(owner);
            if (player == null || player.isSpectator() || distanceToSqr(player) < 25.0D) {
                return false;
            }
            this.target = player;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && distanceToSqr(this.target) > 9.0D;
        }

        @Override
        public void start() {
            this.recalc = 0;
        }

        @Override
        public void tick() {
            if (distanceToSqr(this.target) > 24.0D * 24.0D) {
                teleportTo(this.target.getX() + 1.0D, this.target.getY(), this.target.getZ() + 1.0D);
                getNavigation().stop();
                return;
            }
            if (--this.recalc <= 0) {
                this.recalc = 10;
                getNavigation().moveTo(this.target, 1.2D);
            }
        }
    }
}

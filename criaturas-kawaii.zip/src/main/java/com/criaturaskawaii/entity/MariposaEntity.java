package com.criaturaskawaii.entity;

import com.criaturaskawaii.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Mariposita: vuela de flor en flor y va dejando florecillas sobre la hierba. 5 colores. */
public class MariposaEntity extends KawaiiBase {
    public static final int VARIANTS = 5;
    private static final EntityDataAccessor<Integer> VARIANT =
            SynchedEntityData.defineId(MariposaEntity.class, EntityDataSerializers.INT);
    private static final Block[] FLOWERS = {Blocks.DANDELION, Blocks.POPPY, Blocks.AZURE_BLUET,
            Blocks.CORNFLOWER, Blocks.PINK_TULIP, Blocks.OXEYE_DAISY};

    private boolean variantSet;

    public MariposaEntity(EntityType<? extends MariposaEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 4.0D)
                .add(Attributes.FLYING_SPEED, 0.4D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(this.entityData.get(VARIANT), VARIANTS);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.entityData.get(VARIANT));
        tag.putBoolean("VariantSet", this.variantSet);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(VARIANT, tag.getInt("Variant"));
        this.variantSet = tag.getBoolean("VariantSet");
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, SpawnGroupData data, CompoundTag tag) {
        if (!this.variantSet) {
            this.entityData.set(VARIANT, this.random.nextInt(VARIANTS));
            this.variantSet = true;
        }
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanFloat(true);
        navigation.setCanPassDoors(true);
        return navigation;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.5D));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomFlyingGoal(this, 1.0D));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        if (this.tickCount % 100 == 0 && this.random.nextInt(3) == 0) {
            this.plantFlower();
        }
    }

    private void plantFlower() {
        BlockPos pos = this.blockPosition();
        for (int i = 0; i < 5; i++) {
            BlockPos ground = pos.below(i);
            BlockState state = this.level().getBlockState(ground);
            if (state.isAir()) {
                continue;
            }
            BlockPos above = ground.above();
            if (state.is(Blocks.GRASS_BLOCK) && this.level().getBlockState(above).isAir()) {
                this.level().setBlock(above, FLOWERS[this.random.nextInt(FLOWERS.length)].defaultBlockState(), 3);
                ((ServerLevel) this.level()).sendParticles(ParticleTypes.HAPPY_VILLAGER,
                        above.getX() + 0.5D, above.getY() + 0.4D, above.getZ() + 0.5D, 4, 0.2D, 0.2D, 0.2D, 0.0D);
            }
            return;
        }
    }

    @Override
    protected void onTreat(Player player) {
        for (int i = 0; i < 4; i++) {
            this.plantFlower();
        }
        this.spawnAtLocation(ModItems.POLEN.get());
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.BEE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.BEE_DEATH;
    }
}

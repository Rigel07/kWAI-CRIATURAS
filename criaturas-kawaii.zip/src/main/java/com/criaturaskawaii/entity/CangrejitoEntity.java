package com.criaturaskawaii.entity;

import com.criaturaskawaii.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Cangrejito: timido. Se mete en su concha cuando alguien se acerca de pie
 * (dentro de la concha es inmune). Agachate para acercarte y te regalara
 * alguna Concha Kawaii.
 */
public class CangrejitoEntity extends KawaiiBase {
    private static final EntityDataAccessor<Boolean> HIDDEN =
            SynchedEntityData.defineId(CangrejitoEntity.class, EntityDataSerializers.BOOLEAN);
    private int shy;
    private int shellCooldown;

    public CangrejitoEntity(EntityType<? extends CangrejitoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(HIDDEN, false);
    }

    public boolean isHidden() {
        return this.entityData.get(HIDDEN);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("ShellCooldown", this.shellCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.shellCooldown = tag.getInt("ShellCooldown");
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.isHidden();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isHidden() && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        if (this.shy > 0) {
            this.shy--;
        }
        if (this.shellCooldown > 0) {
            this.shellCooldown--;
        }
        if (this.tickCount % 5 == 0) {
            Player near = this.level().getNearestPlayer(this, 5.0D);
            boolean hide = this.shy <= 0 && near != null && !near.isShiftKeyDown() && !near.isSpectator();
            if (hide != this.isHidden()) {
                this.entityData.set(HIDDEN, hide);
                if (hide) {
                    this.getNavigation().stop();
                    this.playSound(SoundEvents.TURTLE_EGG_CRACK, 0.6F, 1.6F);
                }
            }
        }
    }

    @Override
    protected void onTreat(Player player) {
        this.shy = 600;
        this.entityData.set(HIDDEN, false);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!this.isHidden() && held.isEmpty() && hand == InteractionHand.MAIN_HAND) {
            if (!this.level().isClientSide) {
                this.showHearts();
                this.playSound(SoundEvents.CAT_PURR, 0.5F, 1.8F);
                if (this.shellCooldown <= 0) {
                    this.shellCooldown = 6000;
                    if (this.random.nextBoolean()) {
                        this.spawnAtLocation(new ItemStack(ModItems.CONCHA.get()));
                    }
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.isHidden() ? null : SoundEvents.TURTLE_AMBIENT_LAND;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.TURTLE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.TURTLE_DEATH;
    }
}

package com.criaturaskawaii.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Base de las criaturas. Relacion con "Aventuras Kawaii": si ese mod esta
 * instalado, el Azucar Cristalizado y el Jarabe de Gominola son golosinas que
 * encantan a todas ellas (curan, sacan corazones y activan un efecto propio).
 */
public abstract class KawaiiBase extends PathfinderMob {

    protected KawaiiBase(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static boolean isAventuraTreat(ItemStack stack) {
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return key != null && key.getNamespace().equals("aventuraskawaii")
                && (key.getPath().equals("azucar_cristal") || key.getPath().equals("jarabe_gominola"));
    }

    /** Efecto especial de cada criatura al recibir una golosina. */
    protected void onTreat(Player player) {
    }

    protected void showHearts() {
        if (!this.level().isClientSide) {
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.HEART,
                    this.getX(), this.getY() + this.getBbHeight() + 0.2D, this.getZ(),
                    4, 0.3D, 0.2D, 0.3D, 0.02D);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (isAventuraTreat(held)) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                this.heal(4.0F);
                this.showHearts();
                this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.8F, 1.5F);
                this.onTreat(player);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        if (hand == InteractionHand.MAIN_HAND && held.isEmpty()) {
            if (!this.level().isClientSide) {
                this.showHearts();
                this.playSound(SoundEvents.CAT_PURR, 0.5F, 1.6F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }
}

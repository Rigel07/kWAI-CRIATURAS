package com.criaturaskawaii.entity;

import com.criaturaskawaii.registry.ModItems;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/**
 * Erizito: si lo atacan se hace una bolita y las puas devuelven un pinchacito
 * al agresor. Le encantan las bayas dulces y a veces suelta Puas Suaves.
 */
public class ErizitoEntity extends KawaiiBase {
    private static final EntityDataAccessor<Boolean> CURLED =
            SynchedEntityData.defineId(ErizitoEntity.class, EntityDataSerializers.BOOLEAN);
    private int curlTime;

    public ErizitoEntity(EntityType<? extends ErizitoEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(CURLED, false);
    }

    public boolean isCurled() {
        return this.entityData.get(CURLED);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || this.isCurled();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !this.level().isClientSide) {
            this.curlTime = 100;
            this.entityData.set(CURLED, true);
            this.getNavigation().stop();
            if (source.getEntity() instanceof LivingEntity attacker && source.getDirectEntity() == attacker) {
                attacker.hurt(this.damageSources().thorns(this), 2.0F);
            }
        }
        return hurt;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!this.level().isClientSide && this.isCurled() && --this.curlTime <= 0) {
            this.entityData.set(CURLED, false);
        }
    }

    @Override
    protected void onTreat(Player player) {
        this.spawnAtLocation(ModItems.PUA_SUAVE.get());
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.SWEET_BERRIES)) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                this.heal(3.0F);
                this.entityData.set(CURLED, false);
                this.showHearts();
                if (this.random.nextInt(4) == 0) {
                    this.spawnAtLocation(ModItems.PUA_SUAVE.get());
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.FOX_SNIFF;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.FOX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.FOX_DEATH;
    }
}

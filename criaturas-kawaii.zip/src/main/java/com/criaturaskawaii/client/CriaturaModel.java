package com.criaturaskawaii.client;

import com.criaturaskawaii.CriaturasKawaii;
import com.criaturaskawaii.entity.CangrejitoEntity;
import com.criaturaskawaii.entity.ErizitoEntity;
import com.criaturaskawaii.entity.NubecitoEntity;
import com.criaturaskawaii.entity.PinguinitoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Un modelo para las seis criaturas. Partes fijas: head (hx1..hx3), body,
 * arm_l, arm_r, leg_l, leg_r y x1..x4 (extras segun la criatura).
 */
public class CriaturaModel<T extends Entity> extends EntityModel<T> {

    public enum Kind { CLOUD, CRAB, PENGUIN, BUTTERFLY, SQUIRREL, HEDGEHOG }

    public static final ModelLayerLocation CLOUD_LAYER = layer("nubecito");
    public static final ModelLayerLocation CRAB_LAYER = layer("cangrejito");
    public static final ModelLayerLocation PENGUIN_LAYER = layer("pinguinito");
    public static final ModelLayerLocation BUTTERFLY_LAYER = layer("mariposita");
    public static final ModelLayerLocation SQUIRREL_LAYER = layer("ardillita");
    public static final ModelLayerLocation HEDGEHOG_LAYER = layer("erizito");

    private static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(new ResourceLocation(CriaturasKawaii.MODID, name), "main");
    }

    private final ModelPart root;
    private final ModelPart head, earL, earR, body, armL, armR, legL, legR, x1, x2, x3, x4;
    private final Kind kind;

    public CriaturaModel(ModelPart root, Kind kind) {
        this.root = root;
        this.kind = kind;
        this.head = root.getChild("head");
        this.earL = this.head.getChild("hx2");
        this.earR = this.head.getChild("hx1");
        this.body = root.getChild("body");
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.x1 = root.getChild("x1");
        this.x2 = root.getChild("x2");
        this.x3 = root.getChild("x3");
        this.x4 = root.getChild("x4");
    }

    private static void empty(PartDefinition parent, String name) {
        parent.addOrReplaceChild(name, CubeListBuilder.create(), PartPose.ZERO);
    }

    private static void part(PartDefinition parent, String name, int u, int v, boolean mirror,
                             float x, float y, float z, float w, float h, float d, PartPose pose) {
        CubeListBuilder builder = CubeListBuilder.create().texOffs(u, v);
        if (mirror) {
            builder = builder.mirror();
        }
        parent.addOrReplaceChild(name, builder.addBox(x, y, z, w, h, d), pose);
    }

    private static PartPose at(float x, float y, float z) {
        return PartPose.offset(x, y, z);
    }

    /** Nubecito: corderito de nube con cuatro pompones. */
    public static LayerDefinition createCloud() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -5.0F, 6.0F, 6.0F, 5.0F), at(0, 16, -4));
        part(head, "hx1", 24, 0, false, -1.5F, -1.5F, -0.5F, 3, 3, 1, at(-3.5F, -3.0F, -1.0F));
        part(head, "hx2", 24, 0, true, -1.5F, -1.5F, -0.5F, 3, 3, 1, at(3.5F, -3.0F, -1.0F));
        empty(head, "hx3");
        part(r, "body", 0, 12, false, -5, -3, -4, 10, 6, 8, at(0, 17, 0));
        part(r, "arm_r", 0, 28, false, -1, 0, -1, 2, 4, 2, at(-2.5F, 20, -2.5F));
        part(r, "arm_l", 0, 28, true, -1, 0, -1, 2, 4, 2, at(2.5F, 20, -2.5F));
        part(r, "leg_r", 0, 28, false, -1, 0, -1, 2, 4, 2, at(-2.5F, 20, 2.5F));
        part(r, "leg_l", 0, 28, true, -1, 0, -1, 2, 4, 2, at(2.5F, 20, 2.5F));
        part(r, "x1", 10, 28, false, -3, -4, -3, 6, 4, 6, at(0, 14, 0));
        part(r, "x2", 36, 28, false, -1.5F, -1.5F, -1.5F, 3, 3, 3, at(-4.5F, 13, -2.5F));
        part(r, "x3", 36, 28, false, -1.5F, -1.5F, -1.5F, 3, 3, 3, at(4.5F, 13, 2.5F));
        part(r, "x4", 48, 28, false, -2, -2, 0, 4, 4, 3, at(0, 16, 4));
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Cangrejito: cuerpo plano, pinzas, ojos en tallo y una conchita. */
    public static LayerDefinition createCrab() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 12).addBox(-2.5F, -2.0F, -2.5F, 5.0F, 3.0F, 3.0F), at(0, 18, -3));
        part(head, "hx1", 20, 12, false, -0.5F, -3.0F, -0.5F, 1, 3, 1, at(-1.5F, -2.0F, -1.5F));
        part(head, "hx2", 20, 12, false, -0.5F, -3.0F, -0.5F, 1, 3, 1, at(1.5F, -2.0F, -1.5F));
        empty(head, "hx3");
        part(r, "body", 0, 0, false, -4, -2, -3, 8, 4, 6, at(0, 19, 0));
        part(r, "arm_r", 0, 20, false, -1, -1, -4, 2, 2, 4, at(-4, 19, -2));
        part(r, "arm_l", 0, 20, true, -1, -1, -4, 2, 2, 4, at(4, 19, -2));
        part(r, "leg_r", 0, 28, false, -0.5F, 0, -0.5F, 1, 3, 1, at(-2.5F, 21, 1));
        part(r, "leg_l", 0, 28, true, -0.5F, 0, -0.5F, 1, 3, 1, at(2.5F, 21, 1));
        part(r, "x1", 14, 20, false, -1.5F, -1.5F, -3, 3, 3, 3, at(-4, 19, -6));
        part(r, "x2", 14, 20, true, -1.5F, -1.5F, -3, 3, 3, 3, at(4, 19, -6));
        part(r, "x3", 30, 0, false, -3.5F, -4, -3, 7, 4, 6, at(0, 17, 1));
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Pinguinito: aleteo, picudo y bufanda (solo cuando es tuyo). */
    public static LayerDefinition createPenguin() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F)
                        .texOffs(24, 0).addBox(-1.5F, -3.0F, -5.0F, 3.0F, 2.0F, 2.0F), at(0, 10, 0));
        empty(head, "hx1");
        empty(head, "hx2");
        empty(head, "hx3");
        part(r, "body", 0, 12, false, -3.5F, 0, -2.5F, 7, 13, 5, at(0, 10, 0));
        part(r, "arm_r", 26, 12, false, -0.5F, 0, -1.5F, 1, 7, 3, at(-4, 11, 0));
        part(r, "arm_l", 26, 12, true, -0.5F, 0, -1.5F, 1, 7, 3, at(4, 11, 0));
        part(r, "leg_r", 36, 12, false, -1.5F, 0, -3, 3, 1, 4, at(-2, 23, 0.5F));
        part(r, "leg_l", 36, 12, true, -1.5F, 0, -3, 3, 1, 4, at(2, 23, 0.5F));
        part(r, "x1", 36, 20, false, -1.5F, 0, 0, 3, 2, 2, at(0, 21, 2.5F));
        part(r, "x2", 0, 34, false, -4, 0, -3, 8, 2, 6, at(0, 10, 0));
        empty(r, "x3");
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Mariposita: cuerpo fino, antenas y dos pares de alas. */
    public static LayerDefinition createButterfly() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(18, 0).addBox(-1.5F, -1.5F, -3.0F, 3.0F, 3.0F, 3.0F), at(0, 16, -3));
        head.addOrReplaceChild("hx1", CubeListBuilder.create().texOffs(32, 0).addBox(-0.5F, -3.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(-1.0F, -1.5F, -2.0F, -0.4F, 0.0F, -0.3F));
        head.addOrReplaceChild("hx2", CubeListBuilder.create().texOffs(32, 0).addBox(-0.5F, -3.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(1.0F, -1.5F, -2.0F, -0.4F, 0.0F, 0.3F));
        empty(head, "hx3");
        part(r, "body", 0, 0, false, -1, -1, -3, 2, 2, 6, at(0, 16, 0));
        part(r, "arm_r", 0, 10, false, -7, -0.5F, -3, 7, 1, 6, at(-1, 15.5F, -1));
        part(r, "arm_l", 0, 10, false, 0, -0.5F, -3, 7, 1, 6, at(1, 15.5F, -1));
        part(r, "leg_r", 28, 10, false, -5, -0.5F, 0, 5, 1, 5, at(-1, 15.5F, 1));
        part(r, "leg_l", 28, 10, false, 0, -0.5F, 0, 5, 1, 5, at(1, 15.5F, 1));
        empty(r, "x1");
        empty(r, "x2");
        empty(r, "x3");
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Ardillita: orejas con penacho y una cola enorme. */
    public static LayerDefinition createSquirrel() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 12).addBox(-2.5F, -2.5F, -4.0F, 5.0F, 5.0F, 4.0F), at(0, 18, -3));
        part(head, "hx1", 20, 12, false, -1, -3, -0.5F, 2, 3, 1, at(-1.7F, -2.5F, -1.5F));
        part(head, "hx2", 20, 12, true, -1, -3, -0.5F, 2, 3, 1, at(1.7F, -2.5F, -1.5F));
        part(head, "hx3", 28, 12, false, -1, -0.5F, -2, 2, 2, 2, at(0, 0.5F, -4));
        part(r, "body", 0, 0, false, -2.5F, -2, -3, 5, 4, 6, at(0, 19, 0));
        part(r, "arm_r", 0, 22, false, -1, 0, -1, 2, 3, 2, at(-2, 21, -2));
        part(r, "arm_l", 0, 22, true, -1, 0, -1, 2, 3, 2, at(2, 21, -2));
        part(r, "leg_r", 0, 22, false, -1, 0, -1, 2, 3, 2, at(-2, 21, 2.5F));
        part(r, "leg_l", 0, 22, true, -1, 0, -1, 2, 3, 2, at(2, 21, 2.5F));
        r.addOrReplaceChild("x1", CubeListBuilder.create().texOffs(10, 22).addBox(-2.0F, -8.0F, 0.0F, 4.0F, 8.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, 19.0F, 3.0F, -0.5F, 0.0F, 0.0F));
        empty(r, "x2");
        empty(r, "x3");
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Erizito: cuerpo redondo cubierto de puas suaves. */
    public static LayerDefinition createHedgehog() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition head = r.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(36, 0).addBox(-2.5F, -2.5F, -4.0F, 5.0F, 5.0F, 4.0F), at(0, 20, -3));
        part(head, "hx1", 46, 10, false, -1, -1.5F, -0.5F, 2, 2, 1, at(-2.5F, -2.5F, -2));
        part(head, "hx2", 46, 10, true, -1, -1.5F, -0.5F, 2, 2, 1, at(2.5F, -2.5F, -2));
        part(head, "hx3", 36, 10, false, -1, -0.5F, -2, 2, 2, 2, at(0, 0, -4));
        part(r, "body", 0, 0, false, -4, -3, -4, 8, 6, 8, at(0, 19, 1));
        part(r, "arm_r", 36, 16, false, -1, 0, -1, 2, 2, 2, at(-2.5F, 22, -2.5F));
        part(r, "arm_l", 36, 16, true, -1, 0, -1, 2, 2, 2, at(2.5F, 22, -2.5F));
        part(r, "leg_r", 36, 16, false, -1, 0, -1, 2, 2, 2, at(-2.5F, 22, 3.5F));
        part(r, "leg_l", 36, 16, true, -1, 0, -1, 2, 2, 2, at(2.5F, 22, 3.5F));
        part(r, "x1", 0, 14, false, -4.5F, -5, -4, 9, 3, 8, at(0, 19, 1));
        empty(r, "x2");
        empty(r, "x3");
        empty(r, "x4");
        return LayerDefinition.create(mesh, 64, 64);
    }

    // ------------------------------------------------------------------
    // Animacion
    // ------------------------------------------------------------------

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        float swing = Mth.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
        float sway = Mth.sin(ageInTicks * 0.09F);

        switch (this.kind) {
            case CLOUD -> {
                this.armL.xRot = swing;
                this.legR.xRot = swing;
                this.armR.xRot = -swing;
                this.legL.xRot = -swing;
                boolean fluffy = !(entity instanceof NubecitoEntity n) || n.isReady();
                this.x1.visible = fluffy;
                this.x2.visible = fluffy;
                this.x3.visible = fluffy;
                this.x4.visible = fluffy;
            }
            case CRAB -> {
                boolean hidden = entity instanceof CangrejitoEntity c && c.isHidden();
                this.head.visible = !hidden;
                this.armL.visible = !hidden;
                this.armR.visible = !hidden;
                this.legL.visible = !hidden;
                this.legR.visible = !hidden;
                this.x1.visible = !hidden;
                this.x2.visible = !hidden;
                this.legL.zRot = swing * 0.8F;
                this.legR.zRot = -swing * 0.8F;
                this.armL.zRot = -0.15F - sway * 0.15F;
                this.armR.zRot = 0.15F + sway * 0.15F;
                this.x1.zRot = this.armR.zRot;
                this.x2.zRot = this.armL.zRot;
            }
            case PENGUIN -> {
                this.legL.xRot = swing;
                this.legR.xRot = -swing;
                float flap = Math.abs(swing) * 0.6F;
                this.armL.zRot = -0.1F - flap;
                this.armR.zRot = 0.1F + flap;
                this.x2.visible = entity instanceof PinguinitoEntity p && p.isTamed();
            }
            case BUTTERFLY -> {
                float flap = Mth.sin(ageInTicks * 0.9F) * 0.8F;
                this.armL.zRot = flap;
                this.armR.zRot = -flap;
                this.legL.zRot = flap * 0.8F;
                this.legR.zRot = -flap * 0.8F;
            }
            case SQUIRREL -> {
                this.armL.xRot = swing;
                this.legR.xRot = swing;
                this.armR.xRot = -swing;
                this.legL.xRot = -swing;
                this.x1.zRot = Mth.sin(ageInTicks * 0.1F) * 0.12F;
            }
            default -> {
                boolean curled = entity instanceof ErizitoEntity e && e.isCurled();
                this.head.visible = !curled;
                this.armL.visible = !curled;
                this.armR.visible = !curled;
                this.legL.visible = !curled;
                this.legR.visible = !curled;
                this.armL.xRot = swing;
                this.legR.xRot = swing;
                this.armR.xRot = -swing;
                this.legL.xRot = -swing;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}

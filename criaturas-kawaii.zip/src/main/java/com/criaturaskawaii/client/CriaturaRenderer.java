package com.criaturaskawaii.client;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.function.Function;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;

public class CriaturaRenderer<T extends Mob> extends MobRenderer<T, CriaturaModel<T>> {
    private final Function<T, ResourceLocation> texture;
    private final float scale;

    public CriaturaRenderer(EntityRendererProvider.Context context, CriaturaModel<T> model,
                            float shadowRadius, float scale, Function<T, ResourceLocation> texture) {
        super(context, model, shadowRadius);
        this.texture = texture;
        this.scale = scale;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return this.texture.apply(entity);
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(this.scale, this.scale, this.scale);
    }
}

package com.criaturaskawaii.client;

import com.criaturaskawaii.CriaturasKawaii;
import com.criaturaskawaii.entity.ArdillitaEntity;
import com.criaturaskawaii.entity.CangrejitoEntity;
import com.criaturaskawaii.entity.ErizitoEntity;
import com.criaturaskawaii.entity.MariposaEntity;
import com.criaturaskawaii.entity.NubecitoEntity;
import com.criaturaskawaii.entity.PinguinitoEntity;
import com.criaturaskawaii.registry.ModEntities;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CriaturasKawaii.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(CriaturasKawaii.MODID, "textures/entity/" + name + ".png");
    }

    private static final ResourceLocation[] MARIPOSAS = {
            tex("mariposita_0"), tex("mariposita_1"), tex("mariposita_2"), tex("mariposita_3"), tex("mariposita_4")
    };

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(CriaturaModel.CLOUD_LAYER, CriaturaModel::createCloud);
        event.registerLayerDefinition(CriaturaModel.CRAB_LAYER, CriaturaModel::createCrab);
        event.registerLayerDefinition(CriaturaModel.PENGUIN_LAYER, CriaturaModel::createPenguin);
        event.registerLayerDefinition(CriaturaModel.BUTTERFLY_LAYER, CriaturaModel::createButterfly);
        event.registerLayerDefinition(CriaturaModel.SQUIRREL_LAYER, CriaturaModel::createSquirrel);
        event.registerLayerDefinition(CriaturaModel.HEDGEHOG_LAYER, CriaturaModel::createHedgehog);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.NUBECITO.get(),
                ctx -> new CriaturaRenderer<NubecitoEntity>(ctx,
                        new CriaturaModel<NubecitoEntity>(ctx.bakeLayer(CriaturaModel.CLOUD_LAYER), CriaturaModel.Kind.CLOUD),
                        0.5F, 1.2F, e -> tex("nubecito")));
        event.registerEntityRenderer(ModEntities.CANGREJITO.get(),
                ctx -> new CriaturaRenderer<CangrejitoEntity>(ctx,
                        new CriaturaModel<CangrejitoEntity>(ctx.bakeLayer(CriaturaModel.CRAB_LAYER), CriaturaModel.Kind.CRAB),
                        0.35F, 1.3F, e -> tex("cangrejito")));
        event.registerEntityRenderer(ModEntities.PINGUINITO.get(),
                ctx -> new CriaturaRenderer<PinguinitoEntity>(ctx,
                        new CriaturaModel<PinguinitoEntity>(ctx.bakeLayer(CriaturaModel.PENGUIN_LAYER), CriaturaModel.Kind.PENGUIN),
                        0.35F, 0.85F, e -> tex("pinguinito")));
        event.registerEntityRenderer(ModEntities.MARIPOSITA.get(),
                ctx -> new CriaturaRenderer<MariposaEntity>(ctx,
                        new CriaturaModel<MariposaEntity>(ctx.bakeLayer(CriaturaModel.BUTTERFLY_LAYER), CriaturaModel.Kind.BUTTERFLY),
                        0.15F, 1.1F, e -> MARIPOSAS[e.getVariant()]));
        event.registerEntityRenderer(ModEntities.ARDILLITA.get(),
                ctx -> new CriaturaRenderer<ArdillitaEntity>(ctx,
                        new CriaturaModel<ArdillitaEntity>(ctx.bakeLayer(CriaturaModel.SQUIRREL_LAYER), CriaturaModel.Kind.SQUIRREL),
                        0.3F, 1.2F, e -> tex("ardillita")));
        event.registerEntityRenderer(ModEntities.ERIZITO.get(),
                ctx -> new CriaturaRenderer<ErizitoEntity>(ctx,
                        new CriaturaModel<ErizitoEntity>(ctx.bakeLayer(CriaturaModel.HEDGEHOG_LAYER), CriaturaModel.Kind.HEDGEHOG),
                        0.35F, 1.2F, e -> tex("erizito")));
    }
}

package com.criaturaskawaii;

import com.criaturaskawaii.registry.ModEntities;
import com.criaturaskawaii.registry.ModItems;
import com.criaturaskawaii.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CriaturasKawaii.MODID)
public class CriaturasKawaii {
    public static final String MODID = "criaturaskawaii";

    public CriaturasKawaii() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
    }
}
